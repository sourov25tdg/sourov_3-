Wispbyte setup — NO ENVIRONMENT VARIABLES

1) Upload/extract this project.
2) Install requirements:
   pip install -r requirements.txt
3) Start:
   python app.py

Before going online, open app.py and change:
OWNER_USERNAME = "owner"
OWNER_PASSWORD = "ChangeMe123!"
SECRET_KEY = "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET"

The site uses port 8080 in app.py.
No Wispbyte Environment Variables are required.

IMPORTANT:
- Change the default Owner password before public use.
- This project implements the website/authentication flow.
- TP-Link TL-WR841N captive-portal/network integration is a separate step.
