import os, sqlite3, secrets
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# ===== SITE SETTINGS =====
# Change these values before putting the site online.
SECRET_KEY = "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET"
OWNER_USERNAME = "owner"
OWNER_PASSWORD = "ChangeMe123!"
PORT = 8080
# =========================

app.secret_key = SECRET_KEY
DB = "portal.db"

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    """)
    owner = con.execute("SELECT id FROM users WHERE role='owner' LIMIT 1").fetchone()
    if not owner:
        owner_name = OWNER_USERNAME
        owner_password = OWNER_PASSWORD
        con.execute(
            "INSERT INTO users(name,password_hash,role,status) VALUES(?,?,?,?)",
            (owner_name, generate_password_hash(owner_password), "owner", "approved")
        )
    con.commit()
    con.close()

def current_user():
    uid = session.get("uid")
    if not uid: return None
    con=db(); u=con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone(); con.close()
    return u

def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not current_user():
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper

def role_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            u=current_user()
            if not u or u["role"] not in roles:
                abort(403)
            return fn(*a, **kw)
        return wrapper
    return deco

@app.route("/")
def index():
    return render_template("index.html", user=current_user())

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        password=request.form.get("password","")
        confirm=request.form.get("confirm","")
        if not name or len(name)<2:
            flash("নাম কমপক্ষে ২ অক্ষরের হতে হবে।","error")
        elif len(password)<8:
            flash("পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের দিন।","error")
        elif password != confirm:
            flash("দুইটি পাসওয়ার্ড মিলছে না।","error")
        else:
            con=db()
            exists=con.execute("SELECT id FROM users WHERE lower(name)=lower(?)",(name,)).fetchone()
            if exists:
                flash("এই নামটি ইতিমধ্যে ব্যবহৃত হয়েছে।","error")
            else:
                con.execute("INSERT INTO users(name,password_hash) VALUES(?,?)",
                            (name,generate_password_hash(password)))
                con.commit()
                flash("Registration সফল। Admin approval-এর অপেক্ষায় আছেন।","success")
                con.close()
                return redirect(url_for("login"))
            con.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        password=request.form.get("password","")
        con=db(); u=con.execute("SELECT * FROM users WHERE lower(name)=lower(?)",(name,)).fetchone(); con.close()
        if not u or not check_password_hash(u["password_hash"], password):
            flash("নাম অথবা পাসওয়ার্ড ভুল।","error")
        elif u["status"]!="approved":
            flash("আপনার account এখনো Admin/Owner approve করেননি।","error")
        else:
            session["uid"]=u["id"]
            return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", user=current_user())

@app.route("/admin")
@role_required("admin","owner")
def admin():
    con=db()
    pending=con.execute("SELECT * FROM users WHERE role='user' AND status='pending' ORDER BY id DESC").fetchall()
    approved=con.execute("SELECT * FROM users WHERE role='user' AND status='approved' ORDER BY id DESC").fetchall()
    con.close()
    return render_template("admin.html", user=current_user(), pending=pending, approved=approved)

@app.post("/admin/user/<int:uid>/<action>")
@role_required("admin","owner")
def admin_action(uid, action):
    if action not in ("approve","reject"):
        abort(400)
    con=db()
    if action=="approve":
        con.execute("UPDATE users SET status='approved' WHERE id=? AND role='user'",(uid,))
    else:
        con.execute("DELETE FROM users WHERE id=? AND role='user' AND status='pending'",(uid,))
    con.commit(); con.close()
    return redirect(url_for("admin"))

@app.route("/owner")
@role_required("owner")
def owner():
    con=db()
    users=con.execute("SELECT id,name,role,status,created_at FROM users ORDER BY id DESC").fetchall()
    con.close()
    return render_template("owner.html", user=current_user(), users=users)

@app.post("/owner/user/<int:uid>/make-admin")
@role_required("owner")
def make_admin(uid):
    con=db()
    con.execute("UPDATE users SET role='admin', status='approved' WHERE id=? AND role='user'",(uid,))
    con.commit(); con.close()
    return redirect(url_for("owner"))

@app.post("/owner/user/<int:uid>/remove-admin")
@role_required("owner")
def remove_admin(uid):
    con=db()
    con.execute("UPDATE users SET role='user' WHERE id=? AND role='admin'",(uid,))
    con.commit(); con.close()
    return redirect(url_for("owner"))

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0", port=PORT)
else:
    init_db()
